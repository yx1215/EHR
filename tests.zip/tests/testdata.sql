INSERT INTO patients (last_name,first_name,password,email,phone_number,gender,height,weight,data_of_birth,emergency_contacts,medical_his)
VALUES
  ('a', 'a', 'a','12345@nyu.edu','1234','male','160.0','45.5','1998-11-18','12345','');
INSERT INTO doctors (first_name, last_name, password, email, phone_number, gender, field, date_of_birth, date_of_join)
VALUES
  ('a', 'a', 'a','123@nyu.edu','1234','male','surg','1998-11-18','2020-11-15'),
  ('bob', 'B', 'pbkdf2:sha256:50000$kJPKsz6N$d2d4784f1b030a9761f5ccaeeaca413f27f2ecb76d6168407af962ddce849f79',
  'male','12345678910', 'female', 'surg', '2000-01-01', '2019-01-01');

INSERT INTO administrators (first_name, last_name, password, email, phone_number, gender)
VALUES
  ('a', 'a', 'a','123@nyu.edu','1234','male'),
  ('bob', 'B', 'pbkdf2:sha256:50000$kJPKsz6N$d2d4784f1b030a9761f5ccaeeaca413f27f2ecb76d6168407af962ddce849f79',
  'bob@nyu.edu', '12345', 'male');
